#!/usr/bin/perl
use ExtUtils::testlib;
use Aug::Mar;

$a = Aug::Mar->new("a.mar", AUG_RDWR | AUG_CREAT, 0640)
    or die "error: $!\n";

$i = $a->setfield("name", "mark");
$i = $a->setfield("age", "33");
die "error: $!\n" unless defined $i;
$a->setvalue($i, "34");
$i = $a->unsetbyname("name");
print("$i\n");
$i = $a->unsetbyord(2) or die;

$b = Aug::Mar->new("b.mar", AUG_RDWR | AUG_CREAT, 0640)
    or die "error: $!\n";

$b->copy($a) or die "error: $!\n";

($n, $v) = $b->field(0) or die "error: $!\n";

$a->removefields();

print("$n = $v\n");
