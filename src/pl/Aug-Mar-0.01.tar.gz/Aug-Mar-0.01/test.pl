#!/usr/bin/perl
use ExtUtils::testlib;
use Aug::Mar;
use strict;

my $mar = Aug::Mar->new()
    or die;

$mar->setcontent("some data");

my $s = $mar->content();
print("$s\n");
